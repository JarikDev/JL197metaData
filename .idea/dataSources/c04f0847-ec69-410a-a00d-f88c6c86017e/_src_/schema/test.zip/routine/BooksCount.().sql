CREATE PROCEDURE BooksCount(OUT cnt INT)
  BEGIN
  SELECT count(*) INTO cnt FROM Books;
END;
