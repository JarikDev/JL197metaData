CREATE PROCEDURE getCount()
  BEGIN
  SELECT count(*)
  FROM Users;
  SELECT count(*)
  FROM Books;
END;
